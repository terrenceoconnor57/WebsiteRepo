import React from 'react';
import './Card.css'

const card = (props) => {
  return (
    <div className="Card">
  <input type="text" />
  </div>
)
}



export default card;
