import React, { Component } from 'react';
import {BrowserRouter} from 'react-router-dom';
import './Home.css';

import {Route} from 'react-router-dom';



class Home extends Component {
  render(){
    const style = {
      padding: '20px'
    }

  return (

    <div className="App">

    



    </div>




  );

}
}

export default Home;
