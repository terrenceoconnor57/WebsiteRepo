import React from 'react';
import './ButtonOne.css'
import Buttons from '../Buttons/Buttons'
import {BrowserRouter} from 'react-router-dom';
import {Route} from 'react-router-dom';








const ButtonOne = (props) => {
  return (

<div className = 'buttonone'>
<a className = "One" href = '/Buttons'>Which Cloud?</a>


</div>
)
}


export default ButtonOne;
